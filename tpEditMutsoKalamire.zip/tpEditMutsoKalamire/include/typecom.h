#ifndef TYPECOM_H
#define TYPECOM_H


class typecom
{
    public:
        typecom();
        virtual ~typecom();

    protected:

    private:
};

#endif // TYPECOM_H
